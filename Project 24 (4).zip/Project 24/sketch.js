
const Engine = Matter.Engine;
const World = Matter.World;
const Bodies = Matter.Bodies;
const Body = Matter.Body;

function preload() {

}

function setup() {
	createCanvas(800, 700);






	engine = Engine.create();
	world = engine.world;


	//Create the Bodies Here.
	hammer1 = new Hammers(800, 350, 800, 10);
	ground = new Ground(400, 700, 800, 10);
	stone = new Stone(400, 350, 100, 50);



	Engine.run(engine);

}


function draw() {
	rectMode(CENTER);
	background(10);

	Engine.update(engine);

	hammer1.display();
	ground.display();
	stone.display();



}


